const mymap = L.map('issMap').setView([61.7849, 34.3469], 10);

var osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { 
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'}).addTo(mymap);

var Stadia_AlidadeSmoothDark = L.tileLayer('https://tiles.stadiamaps.com/tiles/alidade_smooth_dark/{z}/{x}/{y}{r}.png', {
	maxZoom: 20,
	attribution: '&copy; <a href="https://stadiamaps.com/">Stadia Maps</a>, &copy; <a href="https://openmaptiles.org/">OpenMapTiles</a> &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors'
});

var Esri_WorldGrayCanvas = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}', {
	attribution: 'Tiles &copy; Esri &mdash; Esri, DeLorme, NAVTEQ',
	maxZoom: 16
});
    
var myIcon = L.icon({
    iconUrl: 'm24.png',
    iconRetinaUrl: 'm48.png',
    iconSize: [29, 24],
    iconAnchor: [9, 21],
    popupAnchor: [0, -14]
});

$.get('./museums.csv', function(csvString) {

// Use PapaParse to convert string to array of objects
var museums = Papa.parse(csvString, {header: true, dynamicTyping: true}).data;

// For each row in data, create a marker and add it to the map
// For each row, columns `Latitude`, `Longitude`, and `Title` are required
   for (var i in museums) {
     var row = museums[i];
     var image = row.image;
     if (row.article) {
       var marker = L.marker([row.lat, row.lon], {
         opacity: 1,
         icon: myIcon
       }).bindPopup('<a href="' + row.article + '" target="_blank"><span style="font-size: 16px; font-family: Verdana, sans-serif;">' + row.name + '</span><br/><img src="' + image + '" style="width: 300px"/></a>');
     } else {
       var marker = L.marker([row.lat, row.lon], {
         opacity: 1,
         icon: myIcon
       }).bindPopup('<span style="font-size: 16px; font-family: Verdana, sans-serif;">' + row.name + '</span><br/><img src="' + image + '" style="width: 300px"/>');
     }
     marker.addTo(mymap);
   }
});

var marker1 = L.circle([59.9412, 30.31549], 8006, {color: 'red'}).addTo(mymap); // Эрмитаж 8006 объектов
var marker2 = L.circle([55.74135, 37.62021], 538, {color: 'blue'}).addTo(mymap); // Третьяковская галерея 538
var marker3 = L.circle([59.93848, 30.32889], 380, {color: 'yellow'}).addTo(mymap); // Русский музей 380 
var marker4 = L.circle([55.74721, 37.60547], 284, {color: 'green'}).addTo(mymap); // Музей изобр. искусств имени А. С. Пушкина 284
var marker5 = L.circle([56.83293, 60.59629], 107, {color: 'purple'}).addTo(mymap); //Екатеринбургский музей изобразительных искусств 107

var allCircles = L.layerGroup([marker1, marker2, marker3, marker4, marker5]);

// Панель поиска
var arcgisOnlineProvider = L.esri.Geocoding.arcgisOnlineProvider({
  apikey: 'AAPKeb33e54f04764eb5af3e22ea6205c49fx9_FqorIB7gXvbNJsgQfAOjxuQDpPKnkJWQnEDYxTzdVxDuKfbPEWdV1ypdFb-p7'
});

var gisDayProvider = L.esri.Geocoding.featureLayerProvider({
  url: 'https://services.arcgis.com/BG6nSlhZSAWtExvp/ArcGIS/rest/services/GIS_Day_Registration_Form_2019_Hosted_View_Layer/FeatureServer/0',
  searchFields: ['event_name', 'host_organization'],
//  label: 'GIS Day Events 2019',
  bufferRadius: 5000,
  formatSuggestion: function (feature) {
    return feature.properties.event_name + ' - ' + feature.properties.host_organization;
  }
});

L.esri.Geocoding.geosearch({
  providers: [arcgisOnlineProvider, gisDayProvider]
}).addTo(mymap);

var baseMaps = {
  'OSM': osm,
  'Black': Stadia_AlidadeSmoothDark,
  'Gray': Esri_WorldGrayCanvas
}

var overlayerMaps = {
  'Museums': allCircles
}

L.control.layers(baseMaps, overlayerMaps).addTo(mymap);